import { createFileRoute, Link } from '@tanstack/react-router'
import { useWishlist } from '@/lib/storage'
import { laptops } from '@/data/laptops'
import { LaptopCard } from '@/components/LaptopCard'
import { Heart, ArrowRight } from 'lucide-react'

export const Route = createFileRoute('/wishlist')({
  component: WishlistPage,
})

function WishlistPage() {
  const { wishlist } = useWishlist()
  const saved = wishlist.map(id => laptops.find(l => l.id === id)).filter(Boolean)

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center gap-3 mb-8">
        <Heart className="w-6 h-6 text-red-500" fill="currentColor" />
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">My Wishlist</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">{saved.length} saved laptop{saved.length !== 1 ? 's' : ''}</p>
        </div>
      </div>

      {saved.length === 0 ? (
        <div className="text-center py-20">
          <Heart className="w-16 h-16 text-gray-200 dark:text-gray-700 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-700 dark:text-gray-300 mb-2">Your wishlist is empty</h2>
          <p className="text-gray-500 dark:text-gray-400 mb-6">Save laptops you love by clicking the ❤️ button</p>
          <Link
            to="/laptops"
            className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-xl transition-colors"
          >
            Browse Laptops <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {saved.map(laptop => laptop && (
            <LaptopCard key={laptop.id} laptop={laptop} />
          ))}
        </div>
      )}
    </div>
  )
}

import { createFileRoute, Link } from '@tanstack/react-router'
import { useState, useEffect, useCallback } from 'react'
import { laptops as staticLaptops } from '@/data/laptops'
import { useCustomLaptops } from '@/lib/storage'
import { formatPrice, cn } from '@/lib/utils'
import { Shield, Plus, Star, Lock, Eye, EyeOff, LayoutDashboard, Laptop, BarChart2, Trash2 } from 'lucide-react'

// Credentials are validated by comparing a SHA-256 hash — the plaintext password
// never appears in this file. To change the password, replace ADMIN_PASS_HASH with
// the SHA-256 hex digest of your new password.
//   Node: require('crypto').createHash('sha256').update('yourpass').digest('hex')
const ADMIN_USER = 'cap'
// SHA-256 of '12345'
const ADMIN_PASS_HASH = '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5'

async function sha256(input: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(input))
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('')
}

// Random nonce created once per page-load. The session token is sha256(nonce + passHash),
// so manually writing any static value to sessionStorage won't grant access.
const SESSION_NONCE = Math.random().toString(36).slice(2)
const SESSION_KEY = 'findlaps_admin_token'

async function makeSessionToken(): Promise<string> {
  return sha256(SESSION_NONCE + ADMIN_PASS_HASH)
}

export const Route = createFileRoute('/admin/')({
  component: AdminPage,
})

function AdminPage() {
  const [authed, setAuthed] = useState(false)
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [error, setError] = useState('')
  const [activeTab, setActiveTab] = useState<'dashboard' | 'laptops'>('dashboard')
  const { custom, remove, update } = useCustomLaptops()

  const allLaptops = [...staticLaptops, ...custom]

  // Re-validate the stored token against the current nonce on mount
  useEffect(() => {
    const stored = sessionStorage.getItem(SESSION_KEY)
    if (!stored) return
    makeSessionToken().then(expected => {
      if (stored === expected) setAuthed(true)
      else sessionStorage.removeItem(SESSION_KEY)
    })
  }, [])

  const login = useCallback(async (e: React.FormEvent) => {
    e.preventDefault()
    const inputHash = await sha256(password)
    if (username === ADMIN_USER && inputHash === ADMIN_PASS_HASH) {
      const token = await makeSessionToken()
      sessionStorage.setItem(SESSION_KEY, token)
      setAuthed(true)
      setError('')
    } else {
      setError('Invalid credentials. Please try again.')
    }
  }, [username, password])

  function logout() {
    sessionStorage.removeItem(SESSION_KEY)
    setAuthed(false)
    setUsername('')
    setPassword('')
  }

  if (!authed) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-8 shadow-xl">
            <div className="text-center mb-8">
              <div className="w-14 h-14 bg-blue-100 dark:bg-blue-900/30 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-blue-600" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Login</h1>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">FindLaps Admin Panel</p>
            </div>

            <form onSubmit={login} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 block mb-1.5">Username</label>
                <input
                  type="text"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  required
                  autoComplete="username"
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter username"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 block mb-1.5">Password</label>
                <div className="relative">
                  <input
                    type={showPass ? 'text' : 'password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    required
                    autoComplete="current-password"
                    className="w-full px-4 py-2.5 pr-10 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(s => !s)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                  >
                    {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              {error && (
                <p className="text-sm text-red-500 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 px-3 py-2 rounded-lg">
                  {error}
                </p>
              )}
              <button
                type="submit"
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl transition-colors"
              >
                <Lock className="w-4 h-4 inline mr-2" />
                Sign In
              </button>
            </form>
          </div>
        </div>
      </div>
    )
  }

  const totalLaptops = allLaptops.length
  const avgPrice = Math.round(allLaptops.reduce((s, l) => s + l.price, 0) / totalLaptops)
  const featured = allLaptops.filter(l => l.featured).length

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center">
            <Shield className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Panel</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">Logged in as <strong>{ADMIN_USER}</strong></p>
          </div>
        </div>
        <button onClick={logout} className="text-sm text-red-500 hover:text-red-600 font-medium border border-red-200 dark:border-red-800 px-3 py-1.5 rounded-lg hover:bg-red-50 transition-colors">
          Sign Out
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 border-b border-gray-200 dark:border-gray-800">
        {[
          { id: 'dashboard' as const, label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
          { id: 'laptops' as const, label: 'Manage Laptops', icon: <Laptop className="w-4 h-4" /> },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              'flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors -mb-px',
              activeTab === tab.id
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            )}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'dashboard' && (
        <div className="space-y-8">
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
            {[
              { label: 'Total Laptops', value: totalLaptops, icon: <Laptop className="w-5 h-5 text-blue-600" />, bg: 'bg-blue-50 dark:bg-blue-900/20' },
              { label: 'Avg. Price', value: formatPrice(avgPrice), icon: <BarChart2 className="w-5 h-5 text-green-600" />, bg: 'bg-green-50 dark:bg-green-900/20' },
              { label: 'Featured', value: featured, icon: <Star className="w-5 h-5 text-yellow-500" />, bg: 'bg-yellow-50 dark:bg-yellow-900/20' },
              { label: 'Custom Added', value: custom.length, icon: <Plus className="w-5 h-5 text-purple-600" />, bg: 'bg-purple-50 dark:bg-purple-900/20' },
            ].map(stat => (
              <div key={stat.label} className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-5">
                <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center mb-3', stat.bg)}>
                  {stat.icon}
                </div>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">{stat.label}</p>
              </div>
            ))}
          </div>

          {/* Quick actions */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-6">
            <h2 className="font-semibold text-gray-900 dark:text-white mb-4">Quick Actions</h2>
            <div className="flex flex-wrap gap-3">
              <Link
                to="/admin/laptops/new"
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-5 py-2.5 rounded-xl transition-colors text-sm"
              >
                <Plus className="w-4 h-4" /> Add New Laptop
              </Link>
              <button
                onClick={() => setActiveTab('laptops')}
                className="flex items-center gap-2 border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 font-semibold px-5 py-2.5 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-sm"
              >
                <Laptop className="w-4 h-4" /> Manage Laptops
              </button>
            </div>
          </div>

          {/* Recent laptops */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="font-semibold text-gray-900 dark:text-white">All Laptops (Last 10)</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 dark:bg-gray-900">
                  <tr>
                    <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wide px-4 py-3">Laptop</th>
                    <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wide px-4 py-3">Brand</th>
                    <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wide px-4 py-3">Price</th>
                    <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wide px-4 py-3">Rating</th>
                    <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wide px-4 py-3">Featured</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                  {allLaptops.slice(0, 10).map(laptop => (
                    <tr key={laptop.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <img src={laptop.images[0]} alt="" className="w-10 h-7 object-cover rounded-lg" />
                          <span className="text-sm font-medium text-gray-900 dark:text-white truncate max-w-48">{laptop.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-400">{laptop.brand}</td>
                      <td className="px-4 py-3 text-sm font-semibold text-gray-900 dark:text-white">{formatPrice(laptop.price)}</td>
                      <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-400">⭐ {laptop.rating}</td>
                      <td className="px-4 py-3">
                        <span className={cn('text-xs font-medium px-2 py-0.5 rounded-full', laptop.featured ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400' : 'bg-gray-100 dark:bg-gray-700 text-gray-500')}>
                          {laptop.featured ? 'Yes' : 'No'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'laptops' && (
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-semibold text-gray-900 dark:text-white">{allLaptops.length} Total Laptops</h2>
            <Link
              to="/admin/laptops/new"
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded-xl transition-colors text-sm"
            >
              <Plus className="w-4 h-4" /> Add Laptop
            </Link>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 dark:bg-gray-900">
                  <tr>
                    <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wide px-4 py-3">Laptop</th>
                    <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wide px-4 py-3 hidden sm:table-cell">Price</th>
                    <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wide px-4 py-3 hidden md:table-cell">Score</th>
                    <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wide px-4 py-3">Featured</th>
                    <th className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wide px-4 py-3">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                  {allLaptops.map(laptop => {
                    const isCustom = custom.some(c => c.id === laptop.id)
                    return (
                      <tr key={laptop.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <img src={laptop.images[0]} alt="" className="w-10 h-7 object-cover rounded" />
                            <div>
                              <p className="text-sm font-medium text-gray-900 dark:text-white truncate max-w-36">{laptop.name}</p>
                              <p className="text-xs text-gray-400">{laptop.brand}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-700 dark:text-gray-300 hidden sm:table-cell">{formatPrice(laptop.price)}</td>
                        <td className="px-4 py-3 text-sm text-gray-700 dark:text-gray-300 hidden md:table-cell">{laptop.performanceScore}</td>
                        <td className="px-4 py-3">
                          <button
                            onClick={() => isCustom && update(laptop.id, { featured: !laptop.featured })}
                            disabled={!isCustom}
                            className={cn(
                              'text-xs font-medium px-2 py-0.5 rounded-full transition-colors',
                              laptop.featured ? 'bg-green-100 dark:bg-green-900/30 text-green-700' : 'bg-gray-100 dark:bg-gray-700 text-gray-500',
                              isCustom ? 'cursor-pointer hover:opacity-80' : 'cursor-default'
                            )}
                          >
                            {laptop.featured ? '✓ Featured' : 'Not Featured'}
                          </button>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <Link
                              to="/laptops/$laptopId"
                              params={{ laptopId: laptop.id }}
                              className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                              title="View"
                            >
                              <Star className="w-3.5 h-3.5" />
                            </Link>
                            {isCustom && (
                              <button
                                onClick={() => {
                                  if (confirm('Delete this laptop?')) remove(laptop.id)
                                }}
                                className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                                title="Delete"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
          <p className="text-xs text-gray-400 mt-3 text-center">Note: Built-in laptops cannot be deleted. Only admin-added laptops can be managed.</p>
        </div>
      )}
    </div>
  )
}

import { createFileRoute, Link, useNavigate } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { useCustomLaptops } from '@/lib/storage'
import type { Laptop } from '@/data/laptops'
import { ArrowLeft, Plus } from 'lucide-react'

export const Route = createFileRoute('/admin/laptops/new')({
  component: NewLaptopPage,
})

function NewLaptopPage() {
  const navigate = useNavigate()
  const { add } = useCustomLaptops()
  const [authed, setAuthed] = useState(false)

  useEffect(() => {
    if (sessionStorage.getItem('findlaps_admin') !== 'true') {
      navigate({ to: '/admin' })
    } else {
      setAuthed(true)
    }
  }, [])

  const [form, setForm] = useState({
    name: '',
    brand: '',
    price: '',
    originalPrice: '',
    processor: '',
    processorBrand: 'Intel' as 'Intel' | 'AMD' | 'Apple',
    ram: '8',
    storage: '512',
    storageType: 'NVMe SSD' as 'HDD' | 'SSD' | 'NVMe SSD',
    gpu: '',
    gpuType: 'Integrated' as 'Integrated' | 'Dedicated',
    display: '',
    displaySize: '15.6',
    battery: '',
    os: 'Windows 11 Home',
    weight: '',
    categories: [] as string[],
    description: '',
    performanceScore: '50',
    featured: false,
    amazonLink: '',
    flipkartLink: '',
    imageUrl: '',
  })
  const [error, setError] = useState('')

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!form.name || !form.brand || !form.price) {
      setError('Please fill in all required fields')
      return
    }
    const id = form.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '') + '-' + Date.now()
    const today = new Date().toISOString().split('T')[0].slice(0, 7)
    const laptop: Laptop = {
      id,
      name: form.name,
      brand: form.brand,
      price: Number(form.price),
      originalPrice: form.originalPrice ? Number(form.originalPrice) : undefined,
      processor: form.processor,
      processorBrand: form.processorBrand,
      ram: Number(form.ram),
      storage: Number(form.storage),
      storageType: form.storageType,
      gpu: form.gpu,
      gpuType: form.gpuType,
      display: form.display,
      displaySize: Number(form.displaySize),
      battery: form.battery,
      os: form.os,
      weight: Number(form.weight),
      categories: form.categories as Laptop['categories'],
      images: [form.imageUrl || 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=800&q=80'],
      rating: 0,
      reviewCount: 0,
      performanceScore: Number(form.performanceScore),
      featured: form.featured,
      amazonLink: form.amazonLink || `https://www.amazon.in/s?k=${encodeURIComponent(form.name)}`,
      flipkartLink: form.flipkartLink || `https://www.flipkart.com/search?q=${encodeURIComponent(form.name)}`,
      description: form.description,
      priceHistory: [{ date: today, price: Number(form.price) }],
      reviews: [],
    }
    add(laptop)
    navigate({ to: '/admin' })
  }

  function update(key: string, value: unknown) {
    setForm(prev => ({ ...prev, [key]: value }))
  }

  function toggleCategory(cat: string) {
    setForm(prev => ({
      ...prev,
      categories: prev.categories.includes(cat)
        ? prev.categories.filter(c => c !== cat)
        : [...prev.categories, cat],
    }))
  }

  if (!authed) return null

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Link to="/admin" className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-xl transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Add New Laptop</h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Section title="Basic Information">
          <Field label="Laptop Name *">
            <input type="text" value={form.name} onChange={e => update('name', e.target.value)} required placeholder="e.g. ASUS ROG Strix G15" className={inputClass} />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Brand *">
              <input type="text" value={form.brand} onChange={e => update('brand', e.target.value)} required placeholder="e.g. ASUS" className={inputClass} />
            </Field>
            <Field label="Featured">
              <label className="flex items-center gap-2 mt-2 cursor-pointer">
                <input type="checkbox" checked={form.featured} onChange={e => update('featured', e.target.checked)} className="w-4 h-4 text-blue-600" />
                <span className="text-sm text-gray-700 dark:text-gray-300">Mark as Featured</span>
              </label>
            </Field>
          </div>
        </Section>

        <Section title="Pricing">
          <div className="grid grid-cols-2 gap-4">
            <Field label="Price in INR (₹) *">
              <input type="number" value={form.price} onChange={e => update('price', e.target.value)} required min={1} placeholder="e.g. 79990" className={inputClass} />
            </Field>
            <Field label="Original Price (₹)">
              <input type="number" value={form.originalPrice} onChange={e => update('originalPrice', e.target.value)} min={1} placeholder="Optional" className={inputClass} />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Amazon Link">
              <input type="url" value={form.amazonLink} onChange={e => update('amazonLink', e.target.value)} placeholder="https://amazon.in/..." className={inputClass} />
            </Field>
            <Field label="Flipkart Link">
              <input type="url" value={form.flipkartLink} onChange={e => update('flipkartLink', e.target.value)} placeholder="https://flipkart.com/..." className={inputClass} />
            </Field>
          </div>
        </Section>

        <Section title="Processor & Performance">
          <div className="grid grid-cols-2 gap-4">
            <Field label="Processor">
              <input type="text" value={form.processor} onChange={e => update('processor', e.target.value)} placeholder="e.g. Intel Core i7-13700H" className={inputClass} />
            </Field>
            <Field label="Processor Brand">
              <select value={form.processorBrand} onChange={e => update('processorBrand', e.target.value)} className={inputClass}>
                <option>Intel</option>
                <option>AMD</option>
                <option>Apple</option>
              </select>
            </Field>
          </div>
          <Field label="Performance Score (0-100)">
            <div className="flex items-center gap-3">
              <input type="range" min={0} max={100} value={form.performanceScore} onChange={e => update('performanceScore', e.target.value)} className="flex-1 accent-blue-600" />
              <span className="text-sm font-bold text-blue-600 w-8 text-right">{form.performanceScore}</span>
            </div>
          </Field>
        </Section>

        <Section title="Memory & Storage">
          <div className="grid grid-cols-3 gap-4">
            <Field label="RAM (GB)">
              <select value={form.ram} onChange={e => update('ram', e.target.value)} className={inputClass}>
                {[4, 8, 16, 32, 64].map(v => <option key={v} value={v}>{v}GB</option>)}
              </select>
            </Field>
            <Field label="Storage (GB)">
              <select value={form.storage} onChange={e => update('storage', e.target.value)} className={inputClass}>
                {[128, 256, 512, 1000, 2000].map(v => <option key={v} value={v}>{v >= 1000 ? `${v/1000}TB` : `${v}GB`}</option>)}
              </select>
            </Field>
            <Field label="Storage Type">
              <select value={form.storageType} onChange={e => update('storageType', e.target.value)} className={inputClass}>
                <option>NVMe SSD</option>
                <option>SSD</option>
                <option>HDD</option>
              </select>
            </Field>
          </div>
        </Section>

        <Section title="GPU & Display">
          <div className="grid grid-cols-2 gap-4">
            <Field label="GPU">
              <input type="text" value={form.gpu} onChange={e => update('gpu', e.target.value)} placeholder="e.g. NVIDIA RTX 4060" className={inputClass} />
            </Field>
            <Field label="GPU Type">
              <select value={form.gpuType} onChange={e => update('gpuType', e.target.value)} className={inputClass}>
                <option>Integrated</option>
                <option>Dedicated</option>
              </select>
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Display">
              <input type="text" value={form.display} onChange={e => update('display', e.target.value)} placeholder="e.g. 15.6 FHD 144Hz IPS" className={inputClass} />
            </Field>
            <Field label="Display Size (inches)">
              <input type="number" value={form.displaySize} onChange={e => update('displaySize', e.target.value)} step={0.1} min={10} max={20} className={inputClass} />
            </Field>
          </div>
        </Section>

        <Section title="Other Details">
          <div className="grid grid-cols-2 gap-4">
            <Field label="Battery">
              <input type="text" value={form.battery} onChange={e => update('battery', e.target.value)} placeholder="e.g. 72Wh" className={inputClass} />
            </Field>
            <Field label="Weight (kg)">
              <input type="number" value={form.weight} onChange={e => update('weight', e.target.value)} step={0.01} min={0.5} max={5} placeholder="e.g. 1.8" className={inputClass} />
            </Field>
          </div>
          <Field label="Operating System">
            <select value={form.os} onChange={e => update('os', e.target.value)} className={inputClass}>
              <option>Windows 11 Home</option>
              <option>Windows 11 Pro</option>
              <option>macOS Sonoma</option>
              <option>FreeDOS</option>
              <option>Chrome OS</option>
            </select>
          </Field>
        </Section>

        <Section title="Categories">
          <div className="flex flex-wrap gap-2">
            {['gaming', 'student', 'business', 'budget', 'creator'].map(cat => (
              <label key={cat} className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border cursor-pointer transition-colors capitalize text-sm font-medium ${form.categories.includes(cat) ? 'bg-blue-600 text-white border-blue-600' : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:border-blue-400'}`}>
                <input
                  type="checkbox"
                  checked={form.categories.includes(cat)}
                  onChange={() => toggleCategory(cat)}
                  className="hidden"
                />
                {cat}
              </label>
            ))}
          </div>
        </Section>

        <Section title="Image & Description">
          <Field label="Image URL">
            <input type="url" value={form.imageUrl} onChange={e => update('imageUrl', e.target.value)} placeholder="https://... (leave blank for default)" className={inputClass} />
          </Field>
          <Field label="Description">
            <textarea value={form.description} onChange={e => update('description', e.target.value)} rows={3} placeholder="Short description of the laptop..." className={inputClass + ' resize-none'} />
          </Field>
        </Section>

        {error && <p className="text-sm text-red-500 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 px-4 py-2 rounded-xl">{error}</p>}

        <div className="flex gap-3 pb-4">
          <button type="submit" className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-xl transition-colors">
            <Plus className="w-5 h-5" /> Add Laptop
          </button>
          <Link to="/admin" className="border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 font-semibold px-6 py-3 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
            Cancel
          </Link>
        </div>
      </form>
    </div>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-6 space-y-4">
      <h2 className="font-semibold text-gray-900 dark:text-white text-sm uppercase tracking-wide border-b border-gray-100 dark:border-gray-700 pb-2">{title}</h2>
      {children}
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-sm font-medium text-gray-600 dark:text-gray-400 block mb-1.5">{label}</label>
      {children}
    </div>
  )
}

const inputClass = 'w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500'

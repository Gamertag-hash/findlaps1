import { createFileRoute, Link } from '@tanstack/react-router'
import { laptops } from '@/data/laptops'
import { LaptopCard } from '@/components/LaptopCard'
import { Search } from 'lucide-react'
import { z } from 'zod'

export const Route = createFileRoute('/search')({
  validateSearch: z.object({ q: z.string().default('') }),
  component: SearchPage,
})

function SearchPage() {
  const { q } = Route.useSearch()
  const navigate = Route.useNavigate()

  const results = q
    ? laptops.filter(l => {
        const query = q.toLowerCase()
        return (
          l.name.toLowerCase().includes(query) ||
          l.brand.toLowerCase().includes(query) ||
          l.processor.toLowerCase().includes(query) ||
          l.gpu.toLowerCase().includes(query) ||
          l.categories.some(c => c.includes(query))
        )
      })
    : []

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Search bar */}
      <div className="mb-8">
        <form
          onSubmit={e => {
            e.preventDefault()
            const fd = new FormData(e.currentTarget)
            const newQ = fd.get('q') as string
            navigate({ search: { q: newQ } })
          }}
          className="flex gap-3 max-w-2xl"
        >
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              name="q"
              defaultValue={q}
              placeholder="Search laptops, brands, specs..."
              className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            type="submit"
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-xl transition-colors"
          >
            Search
          </button>
        </form>
      </div>

      {q ? (
        <>
          <div className="mb-6">
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">
              {results.length > 0 ? `${results.length} results for "${q}"` : `No results for "${q}"`}
            </h1>
          </div>
          {results.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {results.map(laptop => (
                <LaptopCard key={laptop.id} laptop={laptop} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <p className="text-5xl mb-4">🔍</p>
              <p className="text-gray-500 dark:text-gray-400 mb-6">Try searching for a brand, model, or specification like "gaming", "MacBook", "RTX 4070"</p>
              <Link to="/laptops" className="bg-blue-600 text-white font-semibold px-6 py-3 rounded-xl hover:bg-blue-700 transition-colors">
                Browse All Laptops
              </Link>
            </div>
          )}
        </>
      ) : (
        <div className="text-center py-16">
          <Search className="w-16 h-16 text-gray-200 dark:text-gray-700 mx-auto mb-4" />
          <p className="text-gray-500 dark:text-gray-400">Enter a search term to find laptops</p>
        </div>
      )}
    </div>
  )
}

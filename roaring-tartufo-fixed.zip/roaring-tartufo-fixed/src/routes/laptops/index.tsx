import { createFileRoute } from '@tanstack/react-router'
import { useState, useMemo } from 'react'
import { laptops, brands, categories, categoryLabels } from '@/data/laptops'
import { LaptopCard } from '@/components/LaptopCard'
import { SlidersHorizontal, X, ChevronDown, ChevronUp, LayoutGrid, List } from 'lucide-react'
import { cn } from '@/lib/utils'
import { z } from 'zod'

const searchSchema = z.object({
  category: z.enum(['gaming', 'student', 'business', 'budget', 'creator']).optional(),
  brand: z.string().optional(),
  minPrice: z.number().optional(),
  maxPrice: z.number().optional(),
  minRam: z.number().optional(),
  sort: z.string().optional(),
})

export const Route = createFileRoute('/laptops/')({
  validateSearch: (search) => searchSchema.parse(search),
  component: LaptopListing,
})

type SortKey = 'price-asc' | 'price-desc' | 'performance' | 'rating'

function LaptopListing() {
  const search = Route.useSearch()
  const navigate = Route.useNavigate()

  const [localFilters, setLocalFilters] = useState({
    category: search.category || '',
    brand: search.brand || '',
    minPrice: search.minPrice || 0,
    maxPrice: search.maxPrice || 250000,
    minRam: search.minRam || 0,
    sort: (search.sort as SortKey) || 'rating',
    gpu: '',
    storageType: '',
  })
  const [filtersOpen, setFiltersOpen] = useState(false)
  const [gridView, setGridView] = useState(true)

  const filtered = useMemo(() => {
    let result = [...laptops]

    if (localFilters.category) {
      result = result.filter(l => l.categories.includes(localFilters.category as typeof categories[number]))
    }
    if (localFilters.brand) {
      result = result.filter(l => l.brand === localFilters.brand)
    }
    if (localFilters.minPrice > 0) {
      result = result.filter(l => l.price >= localFilters.minPrice)
    }
    if (localFilters.maxPrice < 250000) {
      result = result.filter(l => l.price <= localFilters.maxPrice)
    }
    if (localFilters.minRam > 0) {
      result = result.filter(l => l.ram >= localFilters.minRam)
    }
    if (localFilters.gpu === 'dedicated') {
      result = result.filter(l => l.gpuType === 'Dedicated')
    }
    if (localFilters.storageType) {
      result = result.filter(l => l.storageType === localFilters.storageType)
    }

    switch (localFilters.sort) {
      case 'price-asc': result.sort((a, b) => a.price - b.price); break
      case 'price-desc': result.sort((a, b) => b.price - a.price); break
      case 'performance': result.sort((a, b) => b.performanceScore - a.performanceScore); break
      case 'rating': result.sort((a, b) => b.rating - a.rating); break
    }

    return result
  }, [localFilters])

  function updateFilter(key: string, value: unknown) {
    setLocalFilters(prev => ({ ...prev, [key]: value }))
  }

  function clearFilters() {
    setLocalFilters({ category: '', brand: '', minPrice: 0, maxPrice: 250000, minRam: 0, sort: 'rating', gpu: '', storageType: '' })
  }

  const activeFilterCount = [
    localFilters.category,
    localFilters.brand,
    localFilters.minPrice > 0,
    localFilters.maxPrice < 250000,
    localFilters.minRam > 0,
    localFilters.gpu,
    localFilters.storageType,
  ].filter(Boolean).length

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Top bar */}
      <div className="flex items-center justify-between mb-6 gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">All Laptops</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            {filtered.length} laptop{filtered.length !== 1 ? 's' : ''} found
          </p>
        </div>
        <div className="flex items-center gap-3">
          {/* Sort */}
          <select
            value={localFilters.sort}
            onChange={e => updateFilter('sort', e.target.value)}
            className="text-sm border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 hidden sm:block"
          >
            <option value="rating">Highest Rated</option>
            <option value="price-asc">Price: Low → High</option>
            <option value="price-desc">Price: High → Low</option>
            <option value="performance">Best Performance</option>
          </select>

          {/* View toggle */}
          <div className="flex border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
            <button
              onClick={() => setGridView(true)}
              className={cn('p-2 transition-colors', gridView ? 'bg-blue-600 text-white' : 'bg-white dark:bg-gray-800 text-gray-500 hover:bg-gray-50')}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setGridView(false)}
              className={cn('p-2 transition-colors', !gridView ? 'bg-blue-600 text-white' : 'bg-white dark:bg-gray-800 text-gray-500 hover:bg-gray-50')}
            >
              <List className="w-4 h-4" />
            </button>
          </div>

          {/* Filters toggle (mobile) */}
          <button
            onClick={() => setFiltersOpen(o => !o)}
            className="flex items-center gap-2 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 text-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors lg:hidden"
          >
            <SlidersHorizontal className="w-4 h-4" />
            Filters
            {activeFilterCount > 0 && (
              <span className="bg-blue-600 text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center font-bold">
                {activeFilterCount}
              </span>
            )}
          </button>
        </div>
      </div>

      <div className="flex gap-6">
        {/* Filter sidebar */}
        <aside className={cn(
          'w-64 shrink-0 space-y-5',
          'hidden lg:block',
          filtersOpen && '!block fixed inset-0 z-50 overflow-y-auto bg-white dark:bg-gray-900 p-4 w-full lg:static lg:z-auto lg:overflow-visible lg:p-0 lg:w-64'
        )}>
          <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-5 space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-gray-900 dark:text-white">Filters</h2>
              <div className="flex gap-2">
                {activeFilterCount > 0 && (
                  <button onClick={clearFilters} className="text-xs text-red-500 hover:underline flex items-center gap-1">
                    <X className="w-3 h-3" /> Clear all
                  </button>
                )}
                <button
                  onClick={() => setFiltersOpen(false)}
                  className="lg:hidden text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Category */}
            <FilterSection title="Category">
              <div className="space-y-1.5">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="cat" checked={!localFilters.category} onChange={() => updateFilter('category', '')} className="text-blue-600" />
                  <span className="text-sm text-gray-700 dark:text-gray-300">All Categories</span>
                </label>
                {categories.map(cat => (
                  <label key={cat} className="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="cat" checked={localFilters.category === cat} onChange={() => updateFilter('category', cat)} className="text-blue-600" />
                    <span className="text-sm text-gray-700 dark:text-gray-300">{categoryLabels[cat]}</span>
                  </label>
                ))}
              </div>
            </FilterSection>

            {/* Price Range */}
            <FilterSection title="Price Range">
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                  <span>₹{localFilters.minPrice.toLocaleString('en-IN')}</span>
                  <span>—</span>
                  <span>₹{localFilters.maxPrice === 250000 ? '2,50,000+' : localFilters.maxPrice.toLocaleString('en-IN')}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={250000}
                  step={5000}
                  value={localFilters.maxPrice}
                  onChange={e => updateFilter('maxPrice', Number(e.target.value))}
                  className="w-full accent-blue-600"
                />
                <div className="grid grid-cols-2 gap-2">
                  {[30000, 50000, 80000, 150000].map(p => (
                    <button
                      key={p}
                      onClick={() => updateFilter('maxPrice', p)}
                      className={cn(
                        'text-xs py-1 px-2 rounded-lg border transition-colors',
                        localFilters.maxPrice === p
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 hover:border-blue-500'
                      )}
                    >
                      ≤₹{(p / 1000).toFixed(0)}K
                    </button>
                  ))}
                </div>
              </div>
            </FilterSection>

            {/* Brand */}
            <FilterSection title="Brand">
              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="brand" checked={!localFilters.brand} onChange={() => updateFilter('brand', '')} className="text-blue-600" />
                  <span className="text-sm text-gray-700 dark:text-gray-300">All Brands</span>
                </label>
                {brands.map(b => (
                  <label key={b} className="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="brand" checked={localFilters.brand === b} onChange={() => updateFilter('brand', b)} className="text-blue-600" />
                    <span className="text-sm text-gray-700 dark:text-gray-300">{b}</span>
                    <span className="text-xs text-gray-400 ml-auto">{laptops.filter(l => l.brand === b).length}</span>
                  </label>
                ))}
              </div>
            </FilterSection>

            {/* RAM */}
            <FilterSection title="Minimum RAM">
              <div className="space-y-1.5">
                {[0, 8, 16, 32].map(ram => (
                  <label key={ram} className="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="ram" checked={localFilters.minRam === ram} onChange={() => updateFilter('minRam', ram)} className="text-blue-600" />
                    <span className="text-sm text-gray-700 dark:text-gray-300">{ram === 0 ? 'Any' : `${ram}GB+`}</span>
                  </label>
                ))}
              </div>
            </FilterSection>

            {/* GPU */}
            <FilterSection title="GPU Type">
              <div className="space-y-1.5">
                {[{ v: '', l: 'Any' }, { v: 'dedicated', l: 'Dedicated GPU Only' }].map(opt => (
                  <label key={opt.v} className="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="gpu" checked={localFilters.gpu === opt.v} onChange={() => updateFilter('gpu', opt.v)} className="text-blue-600" />
                    <span className="text-sm text-gray-700 dark:text-gray-300">{opt.l}</span>
                  </label>
                ))}
              </div>
            </FilterSection>
          </div>
        </aside>

        {/* Laptop grid */}
        <div className="flex-1 min-w-0">
          {/* Mobile sort */}
          <div className="sm:hidden mb-4">
            <select
              value={localFilters.sort}
              onChange={e => updateFilter('sort', e.target.value)}
              className="w-full text-sm border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 focus:outline-none"
            >
              <option value="rating">Highest Rated</option>
              <option value="price-asc">Price: Low → High</option>
              <option value="price-desc">Price: High → Low</option>
              <option value="performance">Best Performance</option>
            </select>
          </div>

          {filtered.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-5xl mb-4">🔍</p>
              <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-300 mb-2">No laptops found</h3>
              <p className="text-gray-500 mb-4">Try adjusting your filters</p>
              <button onClick={clearFilters} className="bg-blue-600 text-white px-6 py-2.5 rounded-xl font-semibold hover:bg-blue-700 transition-colors">
                Clear Filters
              </button>
            </div>
          ) : (
            <div className={cn(
              'grid gap-5',
              gridView ? 'grid-cols-1 sm:grid-cols-2 xl:grid-cols-3' : 'grid-cols-1'
            )}>
              {filtered.map(laptop => (
                <LaptopCard key={laptop.id} laptop={laptop} compact={!gridView} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function FilterSection({ title, children }: { title: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(true)
  return (
    <div>
      <button
        onClick={() => setOpen(o => !o)}
        className="flex items-center justify-between w-full text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2"
      >
        {title}
        {open ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
      </button>
      {open && children}
    </div>
  )
}

import { createFileRoute, Link, notFound } from '@tanstack/react-router'
import { laptops } from '@/data/laptops'
import { useWishlist, useCompare, useReviews } from '@/lib/storage'
import { formatPrice, getDiscountPercent, getPerformanceLabel, getPerformanceColor, cn } from '@/lib/utils'
import { StarRating } from '@/components/StarRating'
import { LaptopCard } from '@/components/LaptopCard'
import { Heart, GitCompare, ShoppingCart, ChevronLeft, ChevronRight, TrendingUp, Star, Zap } from 'lucide-react'
import { useState } from 'react'

export const Route = createFileRoute('/laptops/$laptopId')({
  loader: ({ params }) => {
    const laptop = laptops.find(l => l.id === params.laptopId)
    if (!laptop) throw notFound()
    return { laptop }
  },
  component: LaptopDetail,
  notFoundComponent: () => (
    <div className="text-center py-20">
      <p className="text-5xl mb-4">💻</p>
      <h2 className="text-xl font-bold text-gray-700 dark:text-gray-300">Laptop not found</h2>
      <Link to="/laptops" className="mt-4 inline-block text-blue-600 hover:underline">Browse all laptops</Link>
    </div>
  ),
})

function LaptopDetail() {
  const { laptop } = Route.useLoaderData()
  const { has: inWishlist, toggle: toggleWishlist } = useWishlist()
  const { has: inCompare, toggle: toggleCompare, canAdd } = useCompare()
  const { reviews: userReviews, addReview } = useReviews(laptop.id)
  const [activeImage, setActiveImage] = useState(0)
  const [reviewForm, setReviewForm] = useState({ name: '', comment: '', rating: 5 })
  const [showReviewForm, setShowReviewForm] = useState(false)

  const isWishlisted = inWishlist(laptop.id)
  const isCompared = inCompare(laptop.id)
  const discount = getDiscountPercent(laptop.price, laptop.originalPrice)
  const allReviews = [...(laptop.reviews || []), ...userReviews]
  const avgRating = allReviews.length > 0
    ? allReviews.reduce((s, r) => s + r.rating, 0) / allReviews.length
    : laptop.rating

  const related = laptops
    .filter(l => l.id !== laptop.id && l.categories.some(c => laptop.categories.includes(c)))
    .slice(0, 4)

  function submitReview(e: React.FormEvent) {
    e.preventDefault()
    if (!reviewForm.name || !reviewForm.comment) return
    addReview({ userId: 'guest', userName: reviewForm.name, rating: reviewForm.rating, comment: reviewForm.comment })
    setReviewForm({ name: '', comment: '', rating: 5 })
    setShowReviewForm(false)
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mb-6">
        <Link to="/" className="hover:text-blue-600">Home</Link>
        <span>/</span>
        <Link to="/laptops" className="hover:text-blue-600">Laptops</Link>
        <span>/</span>
        <span className="text-gray-900 dark:text-white truncate max-w-48">{laptop.name}</span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-14">
        {/* Image gallery */}
        <div>
          <div className="relative bg-gray-50 dark:bg-gray-800 rounded-2xl overflow-hidden aspect-video mb-3">
            <img
              src={laptop.images[activeImage]}
              alt={laptop.name}
              className="w-full h-full object-cover"
            />
            {laptop.images.length > 1 && (
              <>
                <button
                  onClick={() => setActiveImage(i => (i - 1 + laptop.images.length) % laptop.images.length)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 bg-white/80 dark:bg-gray-900/80 rounded-full flex items-center justify-center shadow hover:bg-white transition-colors"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setActiveImage(i => (i + 1) % laptop.images.length)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 bg-white/80 dark:bg-gray-900/80 rounded-full flex items-center justify-center shadow hover:bg-white transition-colors"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </>
            )}
            {discount && (
              <span className="absolute top-3 left-3 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                -{discount}% OFF
              </span>
            )}
          </div>
          <div className="flex gap-2">
            {laptop.images.map((img, i) => (
              <button
                key={i}
                onClick={() => setActiveImage(i)}
                className={cn(
                  'w-16 h-12 rounded-lg overflow-hidden border-2 transition-colors',
                  activeImage === i ? 'border-blue-600' : 'border-transparent'
                )}
              >
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Info */}
        <div>
          <div className="flex flex-wrap gap-2 mb-3">
            {laptop.categories.map(cat => (
              <span key={cat} className="text-xs bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 px-2 py-0.5 rounded-full font-medium capitalize">
                {cat}
              </span>
            ))}
            {laptop.featured && (
              <span className="text-xs bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 px-2 py-0.5 rounded-full font-medium">
                ⭐ Featured
              </span>
            )}
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">{laptop.brand}</p>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white mb-3 leading-tight">{laptop.name}</h1>

          {/* Rating */}
          <div className="flex items-center gap-3 mb-4">
            <StarRating rating={avgRating} size="md" />
            <span className="font-semibold text-gray-700 dark:text-gray-300">{avgRating.toFixed(1)}</span>
            <span className="text-sm text-gray-500">({laptop.reviewCount + userReviews.length} reviews)</span>
          </div>

          <p className="text-gray-600 dark:text-gray-400 text-sm mb-6 leading-relaxed">{laptop.description}</p>

          {/* Price */}
          <div className="flex items-end gap-3 mb-6">
            <span className="text-3xl font-extrabold text-gray-900 dark:text-white">{formatPrice(laptop.price)}</span>
            {laptop.originalPrice && (
              <>
                <span className="text-lg text-gray-400 line-through">{formatPrice(laptop.originalPrice)}</span>
                <span className="text-green-600 font-semibold text-sm">Save {formatPrice(laptop.originalPrice - laptop.price)}</span>
              </>
            )}
          </div>

          {/* Performance */}
          <div className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4 mb-6 border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-yellow-500" /> Performance Score
              </span>
              <span className={cn('font-bold', getPerformanceColor(laptop.performanceScore))}>
                {laptop.performanceScore}/100 · {getPerformanceLabel(laptop.performanceScore)}
              </span>
            </div>
            <div className="h-2.5 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-500"
                style={{ width: `${laptop.performanceScore}%` }}
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 mb-4">
            <button
              onClick={() => toggleWishlist(laptop.id)}
              className={cn(
                'flex items-center gap-2 px-4 py-3 rounded-xl font-semibold text-sm border transition-all duration-200',
                isWishlisted
                  ? 'bg-red-500 text-white border-red-500 hover:bg-red-600'
                  : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:border-red-400 hover:text-red-500'
              )}
            >
              <Heart className="w-4 h-4" fill={isWishlisted ? 'currentColor' : 'none'} />
              {isWishlisted ? 'Wishlisted' : 'Wishlist'}
            </button>
            <button
              onClick={() => toggleCompare(laptop.id)}
              disabled={!isCompared && !canAdd}
              className={cn(
                'flex items-center gap-2 px-4 py-3 rounded-xl font-semibold text-sm border transition-all duration-200',
                isCompared
                  ? 'bg-blue-600 text-white border-blue-600 hover:bg-blue-700'
                  : canAdd
                    ? 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:border-blue-400 hover:text-blue-600'
                    : 'border-gray-100 text-gray-300 cursor-not-allowed'
              )}
            >
              <GitCompare className="w-4 h-4" />
              {isCompared ? 'In Compare' : 'Compare'}
            </button>
          </div>

          {/* Buy buttons */}
          <div className="grid grid-cols-2 gap-3">
            <a
              href={laptop.amazonLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 py-3.5 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-xl transition-colors"
            >
              <ShoppingCart className="w-5 h-5" /> Buy on Amazon
            </a>
            <a
              href={laptop.flipkartLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors"
            >
              <ShoppingCart className="w-5 h-5" /> Buy on Flipkart
            </a>
          </div>
        </div>
      </div>

      {/* Specs & Reviews */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-14">
        {/* Specs */}
        <div className="lg:col-span-2">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Full Specifications</h2>
          <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden">
            {[
              ['Processor', laptop.processor],
              ['RAM', `${laptop.ram}GB`],
              ['Storage', `${laptop.storage}GB ${laptop.storageType}`],
              ['GPU', laptop.gpu],
              ['GPU Type', laptop.gpuType],
              ['Display', laptop.display],
              ['Battery', laptop.battery],
              ['Operating System', laptop.os],
              ['Weight', `${laptop.weight}kg`],
            ].map(([label, value], i) => (
              <div
                key={label}
                className={cn(
                  'flex items-center justify-between px-5 py-3.5',
                  i % 2 === 0 ? 'bg-gray-50 dark:bg-gray-800' : 'bg-white dark:bg-gray-750'
                )}
              >
                <span className="text-sm text-gray-500 dark:text-gray-400 font-medium">{label}</span>
                <span className="text-sm font-semibold text-gray-900 dark:text-white text-right max-w-xs">{value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Price History */}
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-600" /> Price History
          </h2>
          <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-4">
            <div className="space-y-2.5">
              {laptop.priceHistory.map(point => {
                const max = Math.max(...laptop.priceHistory.map(p => p.price))
                const pct = (point.price / max) * 100
                const isCurrent = point.price === laptop.price
                return (
                  <div key={point.date} className="flex items-center gap-3">
                    <span className="text-xs text-gray-500 w-14 shrink-0">{point.date}</span>
                    <div className="flex-1 bg-gray-100 dark:bg-gray-700 rounded-full h-2 overflow-hidden">
                      <div
                        className={cn('h-full rounded-full', isCurrent ? 'bg-blue-600' : 'bg-gray-400')}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <span className={cn('text-xs font-semibold w-20 text-right shrink-0', isCurrent ? 'text-blue-600' : 'text-gray-600 dark:text-gray-400')}>
                      {formatPrice(point.price)}
                    </span>
                  </div>
                )
              })}
            </div>
            <p className="text-xs text-gray-400 mt-3 text-center">Lowest: {formatPrice(Math.min(...laptop.priceHistory.map(p => p.price)))}</p>
          </div>
        </div>
      </div>

      {/* Reviews */}
      <div className="mb-14">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">
            Reviews & Ratings
          </h2>
          <button
            onClick={() => setShowReviewForm(o => !o)}
            className="text-sm bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl font-semibold transition-colors"
          >
            Write a Review
          </button>
        </div>

        {showReviewForm && (
          <form onSubmit={submitReview} className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-5 mb-6 space-y-4">
            <h3 className="font-semibold text-gray-900 dark:text-white">Your Review</h3>
            <div>
              <label className="text-sm text-gray-600 dark:text-gray-400 mb-1 block">Your Name</label>
              <input
                type="text"
                value={reviewForm.name}
                onChange={e => setReviewForm(p => ({ ...p, name: e.target.value }))}
                required
                className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Your name"
              />
            </div>
            <div>
              <label className="text-sm text-gray-600 dark:text-gray-400 mb-1 block">Rating</label>
              <StarRating rating={reviewForm.rating} size="lg" interactive onChange={r => setReviewForm(p => ({ ...p, rating: r }))} />
            </div>
            <div>
              <label className="text-sm text-gray-600 dark:text-gray-400 mb-1 block">Comment</label>
              <textarea
                value={reviewForm.comment}
                onChange={e => setReviewForm(p => ({ ...p, comment: e.target.value }))}
                required
                rows={3}
                className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                placeholder="Share your experience with this laptop..."
              />
            </div>
            <div className="flex gap-3">
              <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-xl font-semibold text-sm transition-colors">
                Submit Review
              </button>
              <button type="button" onClick={() => setShowReviewForm(false)} className="border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 px-5 py-2 rounded-xl font-semibold text-sm hover:bg-gray-50 transition-colors">
                Cancel
              </button>
            </div>
          </form>
        )}

        {allReviews.length === 0 ? (
          <p className="text-gray-500 dark:text-gray-400 text-center py-8">No reviews yet. Be the first to review!</p>
        ) : (
          <div className="space-y-4">
            {allReviews.map(review => (
              <div key={review.id} className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-5">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-semibold text-gray-900 dark:text-white text-sm">{review.userName}</p>
                    <p className="text-xs text-gray-400">{review.date}</p>
                  </div>
                  <StarRating rating={review.rating} size="sm" />
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">{review.comment}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Related laptops */}
      {related.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Similar Laptops</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {related.map(l => (
              <LaptopCard key={l.id} laptop={l} compact />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

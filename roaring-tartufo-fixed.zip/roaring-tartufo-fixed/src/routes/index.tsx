import { createFileRoute, Link } from '@tanstack/react-router'
import { laptops, categories, categoryLabels, categoryDescriptions, categoryIcons } from '@/data/laptops'
import { LaptopCard } from '@/components/LaptopCard'
import { ArrowRight, TrendingUp, Zap, Star, Shield } from 'lucide-react'

export const Route = createFileRoute('/')({
  component: HomePage,
})

function HomePage() {
  const featured = laptops.filter(l => l.featured).slice(0, 6)
  const under50k = laptops.filter(l => l.price <= 50000).sort((a, b) => b.rating - a.rating).slice(0, 4)
  const under100k = laptops.filter(l => l.price <= 100000 && l.price > 50000).sort((a, b) => b.rating - a.rating).slice(0, 4)
  const trending = [...laptops].sort((a, b) => b.reviewCount - a.reviewCount).slice(0, 4)

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 text-white py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-1.5 text-sm mb-6">
            <Zap className="w-4 h-4 text-yellow-400" />
            <span>India's #1 Laptop Discovery Platform</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-extrabold mb-4 leading-tight">
            Find Your Perfect<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-300 to-purple-300">
              Laptop in India
            </span>
          </h1>
          <p className="text-lg text-blue-100 mb-8 max-w-2xl mx-auto">
            Compare real laptops with updated prices in ₹ INR. Filter by budget, use case, and specs. Get AI-powered recommendations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/laptops"
              className="flex items-center justify-center gap-2 bg-white text-blue-900 font-bold px-8 py-3.5 rounded-xl hover:bg-blue-50 transition-colors shadow-lg"
            >
              Browse All Laptops <ArrowRight className="w-5 h-5" />
            </Link>
            <Link
              to="/compare"
              className="flex items-center justify-center gap-2 border border-white/30 text-white font-semibold px-8 py-3.5 rounded-xl hover:bg-white/10 transition-colors backdrop-blur-sm"
            >
              Compare Laptops
            </Link>
          </div>
          {/* Stats */}
          <div className="flex justify-center gap-8 mt-10 pt-8 border-t border-white/20">
            <Stat value={`${laptops.length}+`} label="Laptops Listed" />
            <Stat value="Real" label="Indian Prices" />
            <Stat value="AI" label="Recommendations" />
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <SectionHeader title="Browse by Category" />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
          {categories.map(cat => (
            <Link
              key={cat}
              to="/laptops"
              search={{ category: cat }}
              className="group flex flex-col items-center gap-3 p-5 bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 hover:border-blue-500 dark:hover:border-blue-500 hover:shadow-lg transition-all duration-200 text-center"
            >
              <span className="text-3xl">{categoryIcons[cat]}</span>
              <div>
                <p className="font-semibold text-gray-900 dark:text-white group-hover:text-blue-600 transition-colors">
                  {categoryLabels[cat]}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 line-clamp-2">
                  {categoryDescriptions[cat]}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Laptops */}
      <section className="max-w-7xl mx-auto px-4 py-8">
        <SectionHeader
          title="Featured Laptops"
          subtitle="Editor's top picks across all categories"
          linkHref="/laptops"
          linkLabel="View all"
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {featured.map(laptop => (
            <LaptopCard key={laptop.id} laptop={laptop} />
          ))}
        </div>
      </section>

      {/* Best under 50k */}
      <section className="bg-orange-50 dark:bg-orange-950/20 py-10">
        <div className="max-w-7xl mx-auto px-4">
          <SectionHeader
            title="Best Under ₹50,000"
            subtitle="Top budget laptops with great value for money"
            linkHref="/laptops?maxPrice=50000"
            linkLabel="See all budget picks"
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {under50k.map(laptop => (
              <LaptopCard key={laptop.id} laptop={laptop} compact />
            ))}
          </div>
        </div>
      </section>

      {/* Best under 1L */}
      <section className="max-w-7xl mx-auto px-4 py-10">
        <SectionHeader
          title="Best Under ₹1,00,000"
          subtitle="Mid-range laptops offering the best performance per rupee"
          linkHref="/laptops?minPrice=50000&maxPrice=100000"
          linkLabel="Explore mid-range"
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {under100k.map(laptop => (
            <LaptopCard key={laptop.id} laptop={laptop} compact />
          ))}
        </div>
      </section>

      {/* Trending */}
      <section className="bg-gray-100 dark:bg-gray-900 py-10">
        <div className="max-w-7xl mx-auto px-4">
          <SectionHeader
            title="🔥 Trending Now"
            subtitle="Most popular laptops among Indian buyers"
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {trending.map(laptop => (
              <LaptopCard key={laptop.id} laptop={laptop} compact />
            ))}
          </div>
        </div>
      </section>

      {/* Why FindLaps */}
      <section className="max-w-7xl mx-auto px-4 py-14">
        <SectionHeader title="Why FindLaps?" subtitle="Everything you need to make the right laptop purchase decision" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { icon: <TrendingUp className="w-6 h-6 text-blue-600" />, title: 'Real Indian Prices', desc: 'Updated prices in ₹ INR from Amazon and Flipkart' },
            { icon: <Zap className="w-6 h-6 text-purple-600" />, title: 'AI Recommendations', desc: 'Get personalized picks based on your budget and needs' },
            { icon: <Star className="w-6 h-6 text-yellow-500" />, title: 'Side-by-Side Compare', desc: 'Compare up to 3 laptops with detailed spec breakdowns' },
            { icon: <Shield className="w-6 h-6 text-green-600" />, title: 'Real Reviews', desc: 'Verified reviews from actual buyers in India' },
          ].map(f => (
            <div key={f.title} className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 text-center">
              <div className="w-12 h-12 bg-gray-50 dark:bg-gray-700 rounded-xl flex items-center justify-center mx-auto mb-4">
                {f.icon}
              </div>
              <h3 className="font-semibold text-gray-900 dark:text-white mb-2">{f.title}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}

function SectionHeader({ title, subtitle, linkHref, linkLabel }: {
  title: string
  subtitle?: string
  linkHref?: string
  linkLabel?: string
}) {
  return (
    <div className="flex items-start justify-between mb-6 gap-4">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{title}</h2>
        {subtitle && <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{subtitle}</p>}
      </div>
      {linkHref && linkLabel && (
        <Link
          to={linkHref as '/laptops'}
          className="shrink-0 flex items-center gap-1 text-sm font-medium text-blue-600 dark:text-blue-400 hover:underline"
        >
          {linkLabel} <ArrowRight className="w-4 h-4" />
        </Link>
      )}
    </div>
  )
}

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div className="text-center">
      <p className="text-2xl font-extrabold text-white">{value}</p>
      <p className="text-sm text-blue-200">{label}</p>
    </div>
  )
}

import { HeadContent, Outlet, Scripts, createRootRoute } from '@tanstack/react-router'
import '../styles.css'
import { Header } from '@/components/Header'
import { CompareBar } from '@/components/CompareBar'
import { AIAssistant } from '@/components/AIAssistant'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { title: 'FindLaps - Discover, Compare & Buy Laptops in India' },
      { name: 'description', content: 'Find the perfect laptop in India. Compare specs, prices, and reviews. Shop from top brands at the best prices.' },
    ],
  }),
  shellComponent: RootDocument,
  component: RootComponent,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body className="bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white min-h-screen">
        {children}
        <Scripts />
      </body>
    </html>
  )
}

function RootComponent() {
  return (
    <>
      <Header />
      <main className="pb-24">
        <Outlet />
      </main>
      <CompareBar />
      <AIAssistant />
    </>
  )
}

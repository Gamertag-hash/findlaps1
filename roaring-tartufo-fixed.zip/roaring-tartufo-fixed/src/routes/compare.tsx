import { createFileRoute, Link } from '@tanstack/react-router'
import { useCompare } from '@/lib/storage'
import { laptops } from '@/data/laptops'
import { formatPrice, cn } from '@/lib/utils'
import { X, GitCompare, Star, Zap, Check, Minus } from 'lucide-react'
import { LaptopCard } from '@/components/LaptopCard'

export const Route = createFileRoute('/compare')({
  component: ComparePage,
})

function ComparePage() {
  const { compareList, toggle, clear } = useCompare()
  const selected = compareList.map(id => laptops.find(l => l.id === id)).filter(Boolean)

  if (selected.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 text-center">
        <GitCompare className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">No Laptops to Compare</h1>
        <p className="text-gray-500 dark:text-gray-400 mb-6">Add laptops to your compare list by clicking "Compare" on any laptop card.</p>
        <Link to="/laptops" className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-xl transition-colors">
          Browse Laptops
        </Link>
      </div>
    )
  }

  if (selected.length === 1) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Add at least 2 laptops to compare</h1>
        <p className="text-gray-500 dark:text-gray-400 mb-8">Currently comparing {selected.length} laptop. Go back and add more.</p>
        <Link to="/laptops" className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-xl transition-colors">
          Browse Laptops
        </Link>
      </div>
    )
  }

  // Determine which laptop is "better" per spec
  const maxPerf = Math.max(...selected.map(l => l!.performanceScore))
  const minPrice = Math.min(...selected.map(l => l!.price))
  const maxRating = Math.max(...selected.map(l => l!.rating))
  const maxRam = Math.max(...selected.map(l => l!.ram))
  const maxStorage = Math.max(...selected.map(l => l!.storage))
  const minWeight = Math.min(...selected.map(l => l!.weight))

  const rows = [
    { label: 'Price', key: 'price', format: (v: unknown) => formatPrice(v as number), best: (v: unknown) => (v as number) === minPrice },
    { label: 'Performance Score', key: 'performanceScore', format: (v: unknown) => `${v}/100`, best: (v: unknown) => (v as number) === maxPerf },
    { label: 'Rating', key: 'rating', format: (v: unknown) => `⭐ ${v}`, best: (v: unknown) => (v as number) === maxRating },
    { label: 'Processor', key: 'processor', format: (v: unknown) => String(v), best: () => false },
    { label: 'RAM', key: 'ram', format: (v: unknown) => `${v}GB`, best: (v: unknown) => (v as number) === maxRam },
    { label: 'Storage', key: 'storage', format: (v: unknown) => `${v}GB`, best: (v: unknown) => (v as number) === maxStorage },
    { label: 'Storage Type', key: 'storageType', format: (v: unknown) => String(v), best: () => false },
    { label: 'GPU', key: 'gpu', format: (v: unknown) => String(v), best: () => false },
    { label: 'GPU Type', key: 'gpuType', format: (v: unknown) => String(v), best: () => false },
    { label: 'Display', key: 'display', format: (v: unknown) => String(v), best: () => false },
    { label: 'Battery', key: 'battery', format: (v: unknown) => String(v), best: () => false },
    { label: 'Weight', key: 'weight', format: (v: unknown) => `${v}kg`, best: (v: unknown) => (v as number) === minWeight },
    { label: 'OS', key: 'os', format: (v: unknown) => String(v), best: () => false },
  ]

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <GitCompare className="w-6 h-6 text-blue-600" /> Laptop Comparison
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Comparing {selected.length} laptops side-by-side</p>
        </div>
        <button onClick={clear} className="text-sm text-red-500 hover:text-red-600 font-medium flex items-center gap-1">
          <X className="w-4 h-4" /> Clear All
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-max">
          {/* Laptop headers */}
          <thead>
            <tr>
              <th className="text-left w-48 pr-4 py-4 text-sm text-gray-500 dark:text-gray-400 font-medium">Specification</th>
              {selected.map(laptop => laptop && (
                <th key={laptop.id} className="px-4 py-4 min-w-52">
                  <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 border border-gray-200 dark:border-gray-700 relative">
                    <button
                      onClick={() => toggle(laptop.id)}
                      className="absolute top-2 right-2 p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
                    >
                      <X className="w-3.5 h-3.5 text-gray-400" />
                    </button>
                    <img src={laptop.images[0]} alt={laptop.name} className="w-full h-28 object-cover rounded-xl mb-3" />
                    <p className="text-xs text-gray-400 font-medium">{laptop.brand}</p>
                    <p className="font-semibold text-gray-900 dark:text-white text-sm mb-2 leading-tight">{laptop.name}</p>
                    <p className="text-lg font-bold text-blue-600">{formatPrice(laptop.price)}</p>
                  </div>
                </th>
              ))}
            </tr>
          </thead>

          {/* Performance bars */}
          <tbody>
            <tr className="border-t border-gray-100 dark:border-gray-800">
              <td className="pr-4 py-4 text-sm text-gray-500 dark:text-gray-400 font-medium flex items-center gap-1">
                <Zap className="w-4 h-4" /> Performance
              </td>
              {selected.map(laptop => laptop && (
                <td key={laptop.id} className="px-4 py-4">
                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-gray-100 dark:bg-gray-700 rounded-full h-3 overflow-hidden">
                      <div
                        className={cn(
                          'h-full rounded-full transition-all',
                          laptop.performanceScore === maxPerf ? 'bg-gradient-to-r from-blue-600 to-purple-600' : 'bg-gray-400'
                        )}
                        style={{ width: `${laptop.performanceScore}%` }}
                      />
                    </div>
                    <span className={cn('text-sm font-bold', laptop.performanceScore === maxPerf ? 'text-blue-600' : 'text-gray-500')}>
                      {laptop.performanceScore}
                    </span>
                  </div>
                </td>
              ))}
            </tr>

            {rows.map((row, idx) => (
              <tr key={row.key} className={cn('border-t border-gray-100 dark:border-gray-800', idx % 2 === 0 ? 'bg-gray-50 dark:bg-gray-900/50' : '')}>
                <td className="pr-4 py-3.5 text-sm text-gray-500 dark:text-gray-400 font-medium">{row.label}</td>
                {selected.map(laptop => laptop && (
                  <td key={laptop.id} className="px-4 py-3.5">
                    <div className="flex items-center gap-1.5">
                      {row.best((laptop as Record<string, unknown>)[row.key]) && (
                        <div className="w-4 h-4 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center shrink-0">
                          <Check className="w-2.5 h-2.5 text-green-600" />
                        </div>
                      )}
                      <span className={cn(
                        'text-sm',
                        row.best((laptop as Record<string, unknown>)[row.key])
                          ? 'font-semibold text-gray-900 dark:text-white'
                          : 'text-gray-600 dark:text-gray-400'
                      )}>
                        {row.format((laptop as Record<string, unknown>)[row.key])}
                      </span>
                    </div>
                  </td>
                ))}
              </tr>
            ))}

            {/* Buy links */}
            <tr className="border-t border-gray-200 dark:border-gray-700">
              <td className="pr-4 py-4 text-sm text-gray-500 font-medium">Buy Now</td>
              {selected.map(laptop => laptop && (
                <td key={laptop.id} className="px-4 py-4">
                  <div className="flex flex-col gap-2">
                    <a
                      href={laptop.amazonLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-center py-2 bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold rounded-xl transition-colors"
                    >
                      Amazon
                    </a>
                    <a
                      href={laptop.flipkartLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-center py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition-colors"
                    >
                      Flipkart
                    </a>
                  </div>
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>

      {/* Add more */}
      {selected.length < 3 && (
        <div className="mt-8 text-center">
          <p className="text-gray-500 dark:text-gray-400 mb-4">You can compare up to 3 laptops. Add one more?</p>
          <Link to="/laptops" className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-xl transition-colors">
            Browse More Laptops
          </Link>
        </div>
      )}
    </div>
  )
}

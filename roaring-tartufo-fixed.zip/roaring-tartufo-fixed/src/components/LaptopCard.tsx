import { Link } from '@tanstack/react-router'
import { Heart, GitCompare, Star, Zap, ShoppingCart } from 'lucide-react'
import type { Laptop } from '@/data/laptops'
import { useWishlist, useCompare } from '@/lib/storage'
import { formatPrice, getDiscountPercent, cn } from '@/lib/utils'

interface LaptopCardProps {
  laptop: Laptop
  compact?: boolean
}

export function LaptopCard({ laptop, compact = false }: LaptopCardProps) {
  const { has: inWishlist, toggle: toggleWishlist } = useWishlist()
  const { has: inCompare, toggle: toggleCompare, canAdd } = useCompare()

  const isWishlisted = inWishlist(laptop.id)
  const isCompared = inCompare(laptop.id)
  const discount = getDiscountPercent(laptop.price, laptop.originalPrice)

  return (
    <div className={cn(
      'group relative bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1 flex flex-col',
      compact && 'rounded-xl'
    )}>
      {/* Image */}
      <div className="relative overflow-hidden bg-gray-50 dark:bg-gray-750">
        <Link to="/laptops/$laptopId" params={{ laptopId: laptop.id }}>
          <img
            src={laptop.images[0]}
            alt={laptop.name}
            className={cn(
              'w-full object-cover transition-transform duration-500 group-hover:scale-105',
              compact ? 'h-36' : 'h-48'
            )}
            loading="lazy"
          />
        </Link>
        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {laptop.featured && (
            <span className="bg-blue-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wide">
              Featured
            </span>
          )}
          {discount && (
            <span className="bg-green-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
              -{discount}%
            </span>
          )}
        </div>
        {/* Wishlist button */}
        <button
          onClick={() => toggleWishlist(laptop.id)}
          className={cn(
            'absolute top-2 right-2 p-1.5 rounded-full transition-all duration-200 shadow-md',
            isWishlisted
              ? 'bg-red-500 text-white'
              : 'bg-white dark:bg-gray-700 text-gray-400 hover:text-red-500'
          )}
          aria-label={isWishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
        >
          <Heart className="w-3.5 h-3.5" fill={isWishlisted ? 'currentColor' : 'none'} />
        </button>
      </div>

      {/* Content */}
      <div className="p-4 flex flex-col flex-1 gap-3">
        <div className="flex-1">
          <p className="text-xs text-gray-400 dark:text-gray-500 font-medium uppercase tracking-wide mb-1">{laptop.brand}</p>
          <Link to="/laptops/$laptopId" params={{ laptopId: laptop.id }}>
            <h3 className={cn(
              'font-semibold text-gray-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 transition-colors line-clamp-2 leading-tight',
              compact ? 'text-sm' : 'text-base'
            )}>
              {laptop.name}
            </h3>
          </Link>

          {/* Rating */}
          <div className="flex items-center gap-1.5 mt-1.5">
            <div className="flex items-center gap-0.5">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className="w-3 h-3"
                  fill={i < Math.floor(laptop.rating) ? '#f59e0b' : 'none'}
                  stroke={i < Math.floor(laptop.rating) ? '#f59e0b' : '#d1d5db'}
                />
              ))}
            </div>
            <span className="text-xs text-gray-500 dark:text-gray-400">
              {laptop.rating} ({laptop.reviewCount.toLocaleString()})
            </span>
          </div>

          {!compact && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              <Spec label={`${laptop.ram}GB`} />
              <Spec label={laptop.storageType === 'HDD' ? `${laptop.storage}GB HDD` : `${laptop.storage}GB SSD`} />
              <Spec label={laptop.processor.split(' ').slice(0, 3).join(' ')} />
            </div>
          )}
        </div>

        {/* Performance bar */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] text-gray-400 dark:text-gray-500 flex items-center gap-0.5">
              <Zap className="w-3 h-3" /> Performance
            </span>
            <span className="text-[10px] font-bold text-gray-600 dark:text-gray-400">{laptop.performanceScore}/100</span>
          </div>
          <div className="h-1.5 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-blue-500 to-purple-500"
              style={{ width: `${laptop.performanceScore}%` }}
            />
          </div>
        </div>

        {/* Price */}
        <div className="flex items-end justify-between">
          <div>
            <p className="text-lg font-bold text-gray-900 dark:text-white">{formatPrice(laptop.price)}</p>
            {laptop.originalPrice && (
              <p className="text-xs text-gray-400 line-through">{formatPrice(laptop.originalPrice)}</p>
            )}
          </div>
          <button
            onClick={() => toggleCompare(laptop.id)}
            disabled={!isCompared && !canAdd}
            className={cn(
              'flex items-center gap-1 text-xs px-2.5 py-1.5 rounded-lg font-medium transition-all duration-200 border',
              isCompared
                ? 'bg-blue-600 text-white border-blue-600 hover:bg-blue-700'
                : canAdd
                  ? 'border-gray-200 dark:border-gray-600 text-gray-500 dark:text-gray-400 hover:border-blue-500 hover:text-blue-600'
                  : 'border-gray-100 dark:border-gray-700 text-gray-300 dark:text-gray-600 cursor-not-allowed'
            )}
            title={!isCompared && !canAdd ? 'Max 3 laptops for comparison' : ''}
          >
            <GitCompare className="w-3 h-3" />
            {isCompared ? 'Added' : 'Compare'}
          </button>
        </div>

        {/* Buy buttons */}
        <div className="flex gap-2">
          <a
            href={laptop.amazonLink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 flex items-center justify-center gap-1 py-2 bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400 text-xs font-semibold rounded-lg hover:bg-orange-100 dark:hover:bg-orange-900/40 transition-colors border border-orange-200 dark:border-orange-800"
          >
            <ShoppingCart className="w-3 h-3" /> Amazon
          </a>
          <a
            href={laptop.flipkartLink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 flex items-center justify-center gap-1 py-2 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 text-xs font-semibold rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-colors border border-blue-200 dark:border-blue-800"
          >
            <ShoppingCart className="w-3 h-3" /> Flipkart
          </a>
        </div>
      </div>
    </div>
  )
}

function Spec({ label }: { label: string }) {
  return (
    <span className="text-[10px] bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 px-1.5 py-0.5 rounded font-medium">
      {label}
    </span>
  )
}

import { useState, useRef, useEffect } from 'react'
import { Bot, X, Send, Laptop2, ChevronDown } from 'lucide-react'
import { laptops } from '@/data/laptops'
import { formatPrice } from '@/lib/utils'
import { Link } from '@tanstack/react-router'

type Category = 'gaming' | 'student' | 'business' | 'budget' | 'creator'

interface Message {
  role: 'assistant' | 'user'
  content: string
  laptops?: typeof laptops
}

const STEPS = [
  {
    id: 'welcome',
    message: "Hi! I'm LapsBot 🤖 - your personal laptop advisor. I'll help you find the perfect laptop. What's your **budget**?\n\n1. Under ₹40,000\n2. ₹40,000 - ₹80,000\n3. ₹80,000 - ₹1,30,000\n4. Above ₹1,30,000",
    key: 'budget',
  },
  {
    id: 'usage',
    message: "Great! What will you **primarily use** it for?\n\n1. Gaming 🎮\n2. Student/Studying 📚\n3. Business/Work 💼\n4. Content Creation 🎨\n5. General Use (browsing, documents)",
    key: 'usage',
  },
  {
    id: 'priority',
    message: "What's most important to you?\n\n1. Performance\n2. Battery life\n3. Weight/Portability\n4. Display quality\n5. Value for money",
    key: 'priority',
  },
]

const budgetRanges: Record<string, [number, number]> = {
  '1': [0, 40000],
  '2': [40000, 80000],
  '3': [80000, 130000],
  '4': [130000, Infinity],
}

const usageCategories: Record<string, Category> = {
  '1': 'gaming',
  '2': 'student',
  '3': 'business',
  '4': 'creator',
  '5': 'student',
}

export function AIAssistant() {
  const [open, setOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: STEPS[0].message },
  ])
  const [step, setStep] = useState(0)
  const [input, setInput] = useState('')
  const [prefs, setPrefs] = useState<Record<string, string>>({})
  const [done, setDone] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  function recommend(preferences: Record<string, string>) {
    const budgetRange = budgetRanges[preferences.budget] || [0, Infinity]
    const category = usageCategories[preferences.usage]

    let filtered = laptops.filter(l => {
      const inBudget = l.price >= budgetRange[0] && l.price <= budgetRange[1]
      const inCategory = !category || l.categories.includes(category)
      return inBudget && inCategory
    })

    if (filtered.length === 0) {
      filtered = laptops.filter(l => l.price >= budgetRange[0] && l.price <= budgetRange[1])
    }

    // Sort by the chosen priority
    const priority = preferences.priority
    if (priority === '1') {
      // Performance
      filtered.sort((a, b) => b.performanceScore - a.performanceScore)
    } else if (priority === '2') {
      // Battery life — sort by battery capacity (extract leading number from e.g. "72Wh" or "10hr")
      filtered.sort((a, b) => {
        const parse = (s: string) => parseFloat(s.replace(/[^0-9.]/g, '')) || 0
        return parse(b.battery) - parse(a.battery)
      })
    } else if (priority === '3') {
      // Weight/Portability — lightest first
      filtered.sort((a, b) => a.weight - b.weight)
    } else if (priority === '4') {
      // Display quality — use rating as best available proxy
      filtered.sort((a, b) => b.rating - a.rating)
    } else {
      // Value for money — best rating per rupee
      filtered.sort((a, b) => (b.rating / b.price) - (a.rating / a.price))
    }

    return filtered.slice(0, 3)
  }

  function handleSend() {
    const trimmed = input.trim()
    if (!trimmed) return

    const userMsg: Message = { role: 'user', content: trimmed }
    const newPrefs = { ...prefs, [STEPS[step]?.key || 'extra']: trimmed }
    setPrefs(newPrefs)
    setInput('')

    const nextStep = step + 1

    if (nextStep < STEPS.length) {
      setMessages(prev => [...prev, userMsg, { role: 'assistant', content: STEPS[nextStep].message }])
      setStep(nextStep)
    } else {
      const recommended = recommend(newPrefs)
      const resultMsg: Message = {
        role: 'assistant',
        content: recommended.length > 0
          ? `Based on your preferences, here are my top picks for you! 🎯`
          : `Hmm, I couldn't find exact matches, but here are some popular options:`,
        laptops: recommended.length > 0 ? recommended : laptops.slice(0, 3),
      }
      setMessages(prev => [...prev, userMsg, resultMsg])
      setDone(true)
    }
  }

  function reset() {
    setMessages([{ role: 'assistant', content: STEPS[0].message }])
    setStep(0)
    setInput('')
    setPrefs({})
    setDone(false)
  }

  function renderContent(content: string) {
    return content.split('\n').map((line, i) => {
      // Render **bold** markers
      const parts = line.split(/\*\*(.+?)\*\*/g)
      return (
        <p key={i} className={line.startsWith('  ') ? 'ml-2' : ''}>
          {parts.map((part, j) =>
            j % 2 === 1 ? <strong key={j}>{part}</strong> : part
          )}
        </p>
      )
    })
  }

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setOpen(o => !o)}
        className="fixed bottom-20 right-6 z-40 w-14 h-14 bg-gradient-to-br from-blue-600 to-purple-600 text-white rounded-full shadow-2xl flex items-center justify-center hover:scale-110 transition-all duration-200"
        aria-label="Open AI assistant"
      >
        {open ? <ChevronDown className="w-6 h-6" /> : <Bot className="w-7 h-7" />}
      </button>

      {/* Chat window */}
      {open && (
        <div className="fixed bottom-36 right-6 z-40 w-80 sm:w-96 bg-white dark:bg-gray-900 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 flex flex-col overflow-hidden" style={{ maxHeight: '520px' }}>
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <div className="flex items-center gap-2">
              <Bot className="w-5 h-5" />
              <div>
                <p className="font-semibold text-sm">LapsBot AI</p>
                <p className="text-xs opacity-80">Laptop Advisor</p>
              </div>
            </div>
            <button onClick={() => setOpen(false)} className="p-1 hover:bg-white/20 rounded-lg transition-colors">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 text-sm">
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {msg.role === 'assistant' && (
                  <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center shrink-0 mr-2 mt-1">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                )}
                <div className={`max-w-[85%] ${msg.role === 'user'
                  ? 'bg-blue-600 text-white rounded-2xl rounded-tr-sm px-3 py-2'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white rounded-2xl rounded-tl-sm px-3 py-2'
                  }`}>
                  <div className="space-y-0.5 whitespace-pre-line text-xs leading-relaxed">
                    {renderContent(msg.content)}
                  </div>
                  {msg.laptops && (
                    <div className="mt-3 space-y-2">
                      {msg.laptops.map(laptop => (
                        <Link
                          key={laptop.id}
                          to="/laptops/$laptopId"
                          params={{ laptopId: laptop.id }}
                          onClick={() => setOpen(false)}
                          className="flex items-center gap-2 bg-white dark:bg-gray-700 rounded-xl p-2 hover:bg-blue-50 dark:hover:bg-gray-600 transition-colors border border-gray-200 dark:border-gray-600"
                        >
                          <img src={laptop.images[0]} alt={laptop.name} className="w-12 h-9 object-cover rounded-lg" />
                          <div className="min-w-0 flex-1">
                            <p className="font-medium text-gray-900 dark:text-white text-xs truncate">{laptop.name}</p>
                            <p className="text-blue-600 dark:text-blue-400 font-bold text-xs">{formatPrice(laptop.price)}</p>
                            <p className="text-gray-400 text-[10px]">Score: {laptop.performanceScore}/100</p>
                          </div>
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            <div ref={bottomRef} />
          </div>

          {/* Input */}
          <div className="p-3 border-t border-gray-200 dark:border-gray-700">
            {done ? (
              <button
                onClick={reset}
                className="w-full py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white text-sm font-semibold rounded-xl hover:opacity-90 transition-opacity"
              >
                Start Over 🔄
              </button>
            ) : (
              <div className="flex gap-2">
                <input
                  type="text"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSend()}
                  placeholder="Type 1, 2, 3... or your answer"
                  className="flex-1 text-xs px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  onClick={handleSend}
                  className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-colors"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  )
}

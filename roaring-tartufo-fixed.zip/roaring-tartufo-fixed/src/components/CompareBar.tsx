import { useNavigate } from '@tanstack/react-router'
import { GitCompare, ArrowRight, X } from 'lucide-react'
import { useCompare } from '@/lib/storage'
import { laptops } from '@/data/laptops'
import { formatPrice } from '@/lib/utils'

export function CompareBar() {
  const { compareList, toggle, clear, limitToast } = useCompare()
  const navigate = useNavigate()

  if (compareList.length === 0 && !limitToast) return null

  const selectedLaptops = compareList.map(id => laptops.find(l => l.id === id)).filter(Boolean)

  return (
    <>
      {/* Toast: shown when user tries to add a 4th laptop */}
      {limitToast && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 bg-gray-900 dark:bg-gray-700 text-white text-sm font-medium px-4 py-2.5 rounded-xl shadow-lg pointer-events-none">
          ⚠️ You can compare up to 3 laptops at a time
        </div>
      )}

      {compareList.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 z-40 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 shadow-2xl">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-4">
            <div className="flex items-center gap-2 shrink-0">
              <GitCompare className="w-5 h-5 text-blue-600" />
              <span className="font-semibold text-gray-900 dark:text-white text-sm hidden sm:block">Compare</span>
            </div>

            <div className="flex items-center gap-3 flex-1 overflow-x-auto">
              {selectedLaptops.map(laptop => laptop && (
                <div key={laptop.id} className="flex items-center gap-2 bg-gray-50 dark:bg-gray-800 rounded-lg px-3 py-1.5 shrink-0 border border-gray-200 dark:border-gray-700">
                  <img src={laptop.images[0]} alt={laptop.name} className="w-8 h-6 object-cover rounded" />
                  <span className="text-xs font-medium text-gray-700 dark:text-gray-300 max-w-28 truncate hidden sm:block">{laptop.name}</span>
                  <span className="text-xs font-bold text-blue-600">{formatPrice(laptop.price)}</span>
                  <button
                    onClick={() => toggle(laptop.id)}
                    className="text-gray-400 hover:text-red-500 transition-colors ml-1"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
              {compareList.length < 3 && (
                <div className="shrink-0 w-24 h-10 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg flex items-center justify-center">
                  <span className="text-xs text-gray-400">+ Add</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={clear}
                className="text-xs text-gray-500 hover:text-red-500 transition-colors"
              >
                Clear
              </button>
              <button
                onClick={() => navigate({ to: '/compare' })}
                disabled={compareList.length < 2}
                className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 dark:disabled:bg-gray-700 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors"
              >
                Compare Now <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

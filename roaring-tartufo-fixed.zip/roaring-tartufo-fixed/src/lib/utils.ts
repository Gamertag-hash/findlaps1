export function formatPrice(price: number): string {
  return `₹${price.toLocaleString('en-IN')}`
}

export function cn(...classes: (string | undefined | null | false)[]): string {
  return classes.filter(Boolean).join(' ')
}

export function slugify(text: string): string {
  return text.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
}

export function getPerformanceLabel(score: number): string {
  if (score >= 90) return 'Extreme'
  if (score >= 75) return 'High'
  if (score >= 60) return 'Good'
  if (score >= 45) return 'Moderate'
  return 'Basic'
}

export function getPerformanceColor(score: number): string {
  if (score >= 90) return 'text-red-500'
  if (score >= 75) return 'text-orange-500'
  if (score >= 60) return 'text-yellow-500'
  if (score >= 45) return 'text-blue-500'
  return 'text-gray-500'
}

export function getDiscountPercent(price: number, originalPrice?: number): number | null {
  if (!originalPrice || originalPrice <= price) return null
  return Math.round(((originalPrice - price) / originalPrice) * 100)
}

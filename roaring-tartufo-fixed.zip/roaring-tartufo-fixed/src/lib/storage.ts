import { useState, useEffect, useCallback } from 'react'

// Generic localStorage hook
function useLocalStorage<T>(key: string, initialValue: T) {
  const [value, setValue] = useState<T>(() => {
    if (typeof window === 'undefined') return initialValue
    try {
      const stored = window.localStorage.getItem(key)
      return stored ? JSON.parse(stored) : initialValue
    } catch {
      return initialValue
    }
  })

  const setStoredValue = useCallback((newValue: T | ((prev: T) => T)) => {
    setValue(prev => {
      const next = typeof newValue === 'function' ? (newValue as (p: T) => T)(prev) : newValue
      if (typeof window !== 'undefined') {
        try {
          window.localStorage.setItem(key, JSON.stringify(next))
        } catch {}
      }
      return next
    })
  }, [key])

  return [value, setStoredValue] as const
}

// Wishlist
export function useWishlist() {
  const [wishlist, setWishlist] = useLocalStorage<string[]>('findlaps_wishlist', [])

  const toggle = useCallback((id: string) => {
    setWishlist(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    )
  }, [setWishlist])

  const has = useCallback((id: string) => wishlist.includes(id), [wishlist])

  return { wishlist, toggle, has }
}

// Compare list
export function useCompare() {
  const [compareList, setCompareList] = useLocalStorage<string[]>('findlaps_compare', [])
  const [limitToast, setLimitToast] = useState(false)

  const toggle = useCallback((id: string) => {
    setCompareList(prev => {
      if (prev.includes(id)) return prev.filter(i => i !== id)
      if (prev.length >= 3) {
        setLimitToast(true)
        setTimeout(() => setLimitToast(false), 2500)
        return prev
      }
      return [...prev, id]
    })
  }, [setCompareList])

  const has = useCallback((id: string) => compareList.includes(id), [compareList])
  const clear = useCallback(() => setCompareList([]), [setCompareList])
  const canAdd = compareList.length < 3

  return { compareList, toggle, has, clear, canAdd, limitToast }
}

// Dark mode
export function useDarkMode() {
  const [dark, setDark] = useLocalStorage<boolean>('findlaps_dark', false)

  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark)
  }, [dark])

  return { dark, toggle: () => setDark(d => !d) }
}

// Reviews
import type { Review } from '@/data/laptops'

export function useReviews(laptopId: string) {
  const [reviews, setReviews] = useLocalStorage<Review[]>(`findlaps_reviews_${laptopId}`, [])

  const addReview = useCallback((review: Omit<Review, 'id' | 'date'>) => {
    const newReview: Review = {
      ...review,
      id: `r_${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
    }
    setReviews(prev => [newReview, ...prev])
  }, [setReviews])

  return { reviews, addReview }
}

// Custom laptops (admin-added)
import type { Laptop } from '@/data/laptops'

export function useCustomLaptops() {
  const [custom, setCustom] = useLocalStorage<Laptop[]>('findlaps_custom_laptops', [])

  const add = useCallback((laptop: Laptop) => {
    setCustom(prev => [laptop, ...prev])
  }, [setCustom])

  const update = useCallback((id: string, data: Partial<Laptop>) => {
    setCustom(prev => prev.map(l => l.id === id ? { ...l, ...data } : l))
  }, [setCustom])

  const remove = useCallback((id: string) => {
    setCustom(prev => prev.filter(l => l.id !== id))
  }, [setCustom])

  return { custom, add, update, remove }
}
